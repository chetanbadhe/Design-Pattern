/**
 * 
 */
package dTunesStore.dataStore;

/**
 * @author ChetanBadhe
 *
 */
public interface IThreads extends Runnable {
	
	public void createThread();
	public void run();

}
